package com.java.jsf;

public class MyResource {

	public String getIt() {
		return "Got it!";
	}
}
