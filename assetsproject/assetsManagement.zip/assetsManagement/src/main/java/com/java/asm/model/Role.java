package com.java.asm.model;

public enum Role {
	ADMIN, EMPLOYEE

}
