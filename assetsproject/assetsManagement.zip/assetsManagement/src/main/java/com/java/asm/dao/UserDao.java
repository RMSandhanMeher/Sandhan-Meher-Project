package com.java.asm.dao;

import java.util.List;
import com.java.asm.model.User;

public interface UserDao {

	boolean addUser(User user);

	User getUserById(int id);

	User getUserByEmail(String email);

	List<User> getAllUsers();

	boolean updateUser(User user);

	boolean deleteUser(int id);

	User authenticate(String email, String password);
}
