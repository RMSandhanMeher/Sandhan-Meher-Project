package com.java.asm.model;

public enum Status {
	ISSUED, RETURNED
}
